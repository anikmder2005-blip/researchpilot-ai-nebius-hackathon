import os
import sys

# Make project packages (config, core, rag, ...) importable when running unittest/pytest from anywhere.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
