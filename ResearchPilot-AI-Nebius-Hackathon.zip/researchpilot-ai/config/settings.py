"""Central configuration. Everything comes from environment variables (optionally a .env file).

No secrets are hardcoded. `validate()` returns human-readable setup problems instead of
raising, so the UI can show a clear setup message.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Mapping, Optional

try:  # python-dotenv is optional at import time so tests run without it
    from dotenv import load_dotenv
except Exception:  # pragma: no cover
    load_dotenv = None

# --- Provider endpoints -------------------------------------------------------
# Nebius Token Factory: OpenAI-compatible API (verified from Nebius/partner docs).
NEBIUS_DEFAULT_BASE_URL = "https://api.tokenfactory.nebius.com/v1/"
# NVIDIA NIM hosted API (build.nvidia.com). Optional, only used when explicitly selected.
NVIDIA_NIM_DEFAULT_BASE_URL = "https://integrate.api.nvidia.com/v1/"

# Model IDs are ASSUMPTIONS taken from public catalog listings. Confirm with
# `python scripts/verify_setup.py --live`, which calls GET /models on your account.
DEFAULT_NEBIUS_MODEL = "nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B"
DEFAULT_NVIDIA_NIM_MODEL = "nvidia/nemotron-3-nano-30b-a3b"
DEFAULT_EMBEDDING_MODEL = "Qwen/Qwen3-Embedding-8B"

SUPPORTED_PROVIDERS = ("nebius", "nvidia_nim")
ALLOWED_UPLOAD_EXTENSIONS = (".pdf", ".txt", ".md", ".markdown")


def _int(env: Mapping[str, str], name: str, default: int) -> int:
    raw = env.get(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _float(env: Mapping[str, str], name: str, default: float) -> float:
    raw = env.get(name, "").strip()
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    provider: str = "nebius"
    llm_api_key: str = field(default="", repr=False)
    llm_base_url: str = NEBIUS_DEFAULT_BASE_URL
    llm_model: str = DEFAULT_NEBIUS_MODEL
    embedding_api_key: str = field(default="", repr=False)
    embedding_base_url: str = NEBIUS_DEFAULT_BASE_URL
    embedding_model: str = DEFAULT_EMBEDDING_MODEL
    tavily_api_key: str = field(default="", repr=False)
    # Limits
    request_timeout_s: int = 90
    max_output_tokens: int = 4096
    agent_max_steps: int = 6          # max tool calls per research run
    agent_max_rounds: int = 2         # max plan/reflect rounds
    agent_deadline_s: int = 240       # wall-clock budget for one run
    web_max_results: int = 5
    doc_top_k: int = 4
    doc_min_score: float = 0.25
    max_upload_mb: int = 10
    max_context_chars: int = 24000
    chunk_size: int = 1000
    chunk_overlap: int = 150
    db_path: str = "data/researchpilot.db"

    @property
    def provider_label(self) -> str:
        return {"nebius": "Nebius Token Factory", "nvidia_nim": "NVIDIA NIM (build.nvidia.com)"}.get(
            self.provider, self.provider
        )

    @property
    def key_env_name(self) -> str:
        return "NEBIUS_API_KEY" if self.provider == "nebius" else "NVIDIA_API_KEY"

    def validate(self, need_search: bool = False) -> list[str]:
        """Return a list of setup problems (empty list == ready)."""
        problems: list[str] = []
        if self.provider not in SUPPORTED_PROVIDERS:
            problems.append(
                f"LLM_PROVIDER must be one of {', '.join(SUPPORTED_PROVIDERS)} (got '{self.provider}')."
            )
        if not self.llm_api_key:
            problems.append(f"{self.key_env_name} is not set. Add it to your .env file.")
        if not self.llm_model:
            problems.append("NEBIUS_MODEL (or NVIDIA_NIM_MODEL) is empty.")
        if not self.llm_base_url.startswith(("http://", "https://")):
            problems.append("The LLM base URL must start with http:// or https://.")
        if not self.embedding_api_key:
            problems.append(
                "No embedding API key available (needs NEBIUS_API_KEY or EMBEDDING_API_KEY). "
                "Document upload/RAG will be disabled."
            )
        if need_search and not self.tavily_api_key:
            problems.append("TAVILY_API_KEY is not set. Web research will be disabled.")
        return problems

    @property
    def llm_ready(self) -> bool:
        return bool(self.llm_api_key and self.llm_model)

    @property
    def search_ready(self) -> bool:
        return bool(self.tavily_api_key)

    @property
    def embeddings_ready(self) -> bool:
        return bool(self.embedding_api_key and self.embedding_model)


def load_settings(env: Optional[Mapping[str, str]] = None, load_env_file: bool = True) -> Settings:
    """Build Settings from an env mapping (defaults to os.environ)."""
    if env is None:
        if load_env_file and load_dotenv is not None:
            load_dotenv(override=False)
        env = os.environ

    provider = env.get("LLM_PROVIDER", "nebius").strip().lower() or "nebius"
    if provider == "nvidia_nim":
        key = env.get("NVIDIA_API_KEY", "").strip()
        base = env.get("NVIDIA_NIM_BASE_URL", "").strip() or NVIDIA_NIM_DEFAULT_BASE_URL
        model = env.get("NVIDIA_NIM_MODEL", "").strip() or DEFAULT_NVIDIA_NIM_MODEL
    else:
        key = env.get("NEBIUS_API_KEY", "").strip()
        base = env.get("NEBIUS_BASE_URL", "").strip() or NEBIUS_DEFAULT_BASE_URL
        model = env.get("NEBIUS_MODEL", "").strip() or DEFAULT_NEBIUS_MODEL

    # Embeddings default to Nebius (the generation model cannot embed).
    emb_key = env.get("EMBEDDING_API_KEY", "").strip() or env.get("NEBIUS_API_KEY", "").strip()
    emb_base = env.get("EMBEDDING_BASE_URL", "").strip() or env.get("NEBIUS_BASE_URL", "").strip() or NEBIUS_DEFAULT_BASE_URL
    emb_model = env.get("EMBEDDING_MODEL", "").strip() or DEFAULT_EMBEDDING_MODEL

    return Settings(
        provider=provider,
        llm_api_key=key,
        llm_base_url=base if base.endswith("/") else base + "/",
        llm_model=model,
        embedding_api_key=emb_key,
        embedding_base_url=emb_base if emb_base.endswith("/") else emb_base + "/",
        embedding_model=emb_model,
        tavily_api_key=env.get("TAVILY_API_KEY", "").strip(),
        request_timeout_s=_int(env, "REQUEST_TIMEOUT_S", 90),
        max_output_tokens=_int(env, "MAX_OUTPUT_TOKENS", 4096),
        agent_max_steps=max(1, _int(env, "AGENT_MAX_STEPS", 6)),
        agent_max_rounds=max(1, _int(env, "AGENT_MAX_ROUNDS", 2)),
        agent_deadline_s=max(10, _int(env, "AGENT_DEADLINE_S", 240)),
        web_max_results=max(1, min(10, _int(env, "WEB_MAX_RESULTS", 5))),
        doc_top_k=max(1, min(10, _int(env, "DOC_TOP_K", 4))),
        doc_min_score=_float(env, "DOC_MIN_SCORE", 0.25),
        max_upload_mb=max(1, _int(env, "MAX_UPLOAD_MB", 10)),
        max_context_chars=max(4000, _int(env, "MAX_CONTEXT_CHARS", 24000)),
        chunk_size=max(200, _int(env, "CHUNK_SIZE", 1000)),
        chunk_overlap=max(0, _int(env, "CHUNK_OVERLAP", 150)),
        db_path=env.get("DB_PATH", "").strip() or "data/researchpilot.db",
    )


def redact(text: str, *secrets: str) -> str:
    """Remove known secret values from text (used for logs and error messages)."""
    out = text or ""
    for s in secrets:
        if s and len(s) >= 6:
            out = out.replace(s, "***")
    return out
